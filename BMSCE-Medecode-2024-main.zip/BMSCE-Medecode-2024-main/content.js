/*============================================
                  CONTENT
============================================*/
const Content = {
    fruit: [
      ["strawberry", "match1"],
      ["strawberry", "match1"],
      ["lemon", "match2"],
      ["lemon", "match2"],
      ["grapes", "match3"],
      ["grapes", "match3"],
      ["cherries", "match4"],
      ["cherries", "match4"],
      ["pear", "match5"],
      ["pear", "match5"],
      ["peach","match6" ],
      ["peach","match6" ],
      ["apple", "match7"],
      ["apple", "match7"],
      ["orange", "match8"],
      ["orange", "match8"]
    ],
    animals: [
      ["bird", "match1"],
      ["bird", "match1"],
      ["elephant", "match2"],
      ["elephant", "match2"],
      ["tiger", "match3"],
      ["tiger", "match3"],
      ["lion", "match4"],
      ["lion", "match4"],
      ["monkey", "match5"],
      ["monkey", "match5"],
      ["turkey","match6" ],
      ["turkey","match6" ],
      ["eagle", "match7"],
      ["eagle", "match7"],
      ["zebra", "match8"],
      ["zebra", "match8"]
    ],
    spanish: [
      ["hello", "match1"],
      ["namaskara", "match1"],
      ["goodbye", "match2"],
      ["vidaya", "match2"],
      ["grapes", "match3"],
      ["draksigalu", "match3"],
      ["horse", "match4"],
      ["kudure", "match4"],
      ["car", "match5"],
      ["caru", "match5"],
      ["house", "match6"],
      ["mane", "match6"],
      ["apple", "match7"],
      ["sebu", "match7"],
      ["table", "match8"],
      ["tabel", "match8"]
    ],
    
    animal_sounds: [
        ["cow", "match1"],
        ["Moo", "match1"],
        ["duck", "match2"],
        ["Quack", "match2"],
        ["elephant", "match3"],
        ["Trumpet", "match3"],
        ["goat", "match4"],
        ["bleet", "match4"],
        ["dog", "match5"],
        ["bark", "match5"],
        ["horse","match6"],
        ["neigh","match6" ],
        ["frog", "match7"],
        ["ribbit", "match7"],
        ["bee", "match8"],
        ["buzz", "match8"]
      ],
    
  };