# BMSCE-Medecode-2024
NeuroCare is a stroke rehabilitation website aimed at step-by-step recovery for stroke patients. This website facilitates appointment booking, games to improve cognitive skills and neurorehabilitation tests like TUG(Timed Up and Go) test, 10 Metre walk test and Berg Balance Scale test.
[Visit the website](https://preethi-nt.github.io/BMSCE-Medecode-2024/)
